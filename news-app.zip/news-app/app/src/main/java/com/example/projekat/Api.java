package com.example.projekat;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Api {

    public static void dobaviVest(final String link, final ReadDataHandler rdh) {
        AsyncTask<String, Void, String> task = new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... strings) {
                String response = "";

                try {
                    URL url = new URL(link);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("GET");

                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    String line = "";
                    while(line != null) {
                        line = bufferedReader.readLine();
                        response += line;
                    }

                    bufferedReader.close();
                    httpURLConnection.disconnect();


                } catch (Exception e) {
                    response = e.getMessage();
                }


                return  response;
            }

            @Override
            protected void onPostExecute(String response) {
                rdh.setResponseJsonString(response);
                rdh.sendEmptyMessage(0);

            }
        };

        task.execute();
    }
}
