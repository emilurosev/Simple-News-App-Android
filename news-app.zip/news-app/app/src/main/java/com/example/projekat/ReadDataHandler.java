package com.example.projekat;


import android.os.Handler;

public class ReadDataHandler extends Handler {
    private String responseJsonString = "";

    public void setResponseJsonString(String responseJsonString) {
        this.responseJsonString = responseJsonString;
    }

    public String getResponseJsonString() {
        return responseJsonString;
    }


}
