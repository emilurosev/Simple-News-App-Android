package com.example.projekat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class Vest {
    private String naslov, datum, sadrzaj, urlSlike, kategorija;
    private String id;

    public Vest() {

    }

    public Vest(String id, String naslov, String datum, String sadrzaj, String urlSlike, String kategorija) {
        this.id = id;
        this.naslov = naslov;
        this.datum = datum;
        this.sadrzaj = sadrzaj;
        this.urlSlike = urlSlike;
        this.kategorija = kategorija;
    }


    public String getNaslov() {
        return naslov;
    }

    public void setNaslov(String naslov) {
        this.naslov = naslov;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public String getSadrzaj() {
        return sadrzaj;
    }

    public void setSadrzaj(String sadrzaj) {
        this.sadrzaj = sadrzaj;
    }

    public String getUrlSlike() {
        return urlSlike;
    }

    public void setUrlSlike(String urlSlike) {
        this.urlSlike = urlSlike;
    }

    public String getKategorija() {
        return kategorija;
    }

    public void setKategorija(String kategorija) {
        this.kategorija = kategorija;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public static Vest oneJSONObjectParsed(JSONObject jsonObject) {
        Vest vest = new Vest();
        try {
            if (jsonObject.has("id")) {
                vest.setId(jsonObject.getString("id"));
            }
            if(jsonObject.has("naslov")) {
                vest.setNaslov(jsonObject.getString("naslov"));
            }
            if(jsonObject.has("datum")) {
                vest.setDatum(jsonObject.getString("datum"));
            }
            if(jsonObject.has("sadrzaj")) {
                vest.setSadrzaj(jsonObject.getString("sadrzaj"));
            }
            if(jsonObject.has("urlSlike")) {
                vest.setUrlSlike(jsonObject.getString("urlSlike"));
            }
            if(jsonObject.has("kategorija")) {
                vest.setKategorija(jsonObject.getString("kategorija"));
            }

        }
        catch(Exception e) {

        }

        return  vest;

    }

    public static ArrayList<Vest> parseJSONArray(JSONArray jsonArray) {
        ArrayList<Vest> list = new ArrayList<>();
        for(int i = 0; i < jsonArray.length(); i++) {
            try {
                Vest vest = oneJSONObjectParsed(jsonArray.getJSONObject(i));
                list.add(vest);
            } catch (Exception e) {

            }
        }
        return list;
    }

    public static ArrayList<Vest> parseJSONArrayByCategory(JSONArray jsonArray, String category) {
        ArrayList<Vest> listByCategory = new ArrayList<>();
        for(int i = 0; i < jsonArray.length(); i++) {
            try {
                Vest vest = oneJSONObjectParsed(jsonArray.getJSONObject(i));
                if(vest.getKategorija().equals(category)) {
                    listByCategory.add(vest);
                }
            } catch (Exception e) {

            }
        }

        return listByCategory;
    }



}
