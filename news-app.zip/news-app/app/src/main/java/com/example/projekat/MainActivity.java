package com.example.projekat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static String kategorija, jezik;
    LinearLayout mainElement;
    Button vestiButton, sportButton, svetButton, srbijaButton;
    private static final String APP_DATA_PREFIX = "MainActivityAppDataPrefix";
    Spinner jezikSpinner;
    private static final String URL_ENG = "http://192.168.0.16:5000/jsonEng";
    private static final String URL_SRB = "http://192.168.0.16:5000/json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kategorija = "";
        jezik = "Srpski";
        loadFromFile();




        vestiButton = (Button)findViewById(R.id.vestiButton);
        sportButton = (Button)findViewById(R.id.sportButton);
        svetButton = (Button)findViewById(R.id.svetButton);
        srbijaButton = (Button)findViewById(R.id.srbijaButton);

        translate();


        mainElement = (LinearLayout)findViewById(R.id.mainElement);


        jezikSpinner = (Spinner)findViewById(R.id.jezikSpinner);


        vestiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainElement.removeAllViews();
                kategorija = "";
                initVesti(kategorija, urlCheck());

            }
        });


        sportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainElement.removeAllViews();
                kategorija = "sport";
                initVesti(kategorija, urlCheck());
            }
        });

        svetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainElement.removeAllViews();
                kategorija = "svet";
                initVesti(kategorija, urlCheck());
            }
        });


        srbijaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainElement.removeAllViews();
                kategorija = "srbija";
                initVesti(kategorija, urlCheck());
            }
        });



        jezikSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String j = jezikSpinner.getSelectedItem().toString();
                jezik = j;
                translate();
                mainElement.removeAllViews();
                initVesti(kategorija, urlCheck());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveOnFile();
    }

    @Override
    protected void onStop() {
        super.onStop();
        saveOnFile();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveOnFile();
    }

    @SuppressLint("HandlerLeak")
    public void initVesti(final String kategorijaTmp, String url) {
        Api.dobaviVest(url, new ReadDataHandler() {
            @Override
            public void handleMessage(Message msg) {
                String odgovor = getResponseJsonString();

                try {
                    JSONArray jsonArray = new JSONArray(odgovor);
                    ArrayList<Vest> vesti;
                    if(kategorijaTmp.isEmpty() || (!kategorijaTmp.equals("sport") && !kategorijaTmp.equals("srbija") && !kategorijaTmp.equals("svet")) ) {
                        vesti = Vest.parseJSONArray(jsonArray);
                    }
                    else {
                        vesti = Vest.parseJSONArrayByCategory(jsonArray, kategorijaTmp);
                    }


                    for(Vest v : vesti) {

                        if(vesti.indexOf(v) == 0) {
                            LayoutInflater layoutInflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                            RelativeLayout prvaVest = (RelativeLayout)layoutInflater.inflate(R.layout.prva_vest, null);

                            TextView datumPrveVesti = (TextView)prvaVest.findViewById(R.id.datumPrveVest);
                            datumPrveVesti.setText(v.getDatum());
                            TextView naslovPrveVesti = (TextView)prvaVest.findViewById(R.id.naslovPrveVesti);
                            naslovPrveVesti.setText(v.getNaslov());
                            if(kategorijaTmp.equals("sport")) {
                                naslovPrveVesti.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
                            }
                            else if(kategorijaTmp.equals("srbija")) {
                                naslovPrveVesti.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                            }
                            else if(kategorijaTmp.equals("svet")) {
                                naslovPrveVesti.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                            }
                            else
                                naslovPrveVesti.setTextColor(getResources().getColor(android.R.color.holo_purple));

                            ImageView slikaPrveVest = (ImageView)prvaVest.findViewById(R.id.slikaPrveVesti);

                            if(v.getKategorija().equals("svet")) {
                                slikaPrveVest.setImageResource(R.drawable.svet_projekat_rma);
                            }
                            else if(v.getKategorija().equals("srbija")) {
                                slikaPrveVest.setImageResource(R.drawable.srbija_projekat_rma);
                            }
                            else if(v.getKategorija().equals("sport")) {
                                slikaPrveVest.setImageResource(R.drawable.sport_projekat_rma);
                            }
                            else {
                                slikaPrveVest.setImageResource(R.drawable.vesti_projekat_rma);
                            }

                            final String idToBePassed = v.getId();

                            prvaVest.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent i = new Intent(MainActivity.this, PojedinacnaVestActivity.class);
                                    i.putExtra("id", idToBePassed);
                                    i.putExtra("jezik", jezik);
                                    startActivity(i);
                                }
                            });



                            mainElement.addView(prvaVest);
                        }
                        else {
                            LayoutInflater layoutInflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                            RelativeLayout vest = (RelativeLayout)layoutInflater.inflate(R.layout.vest, null);

                            TextView datumVesti = (TextView)vest.findViewById(R.id.datumVesti);
                            datumVesti.setText(v.getDatum());
                            TextView naslovVesti = (TextView)vest.findViewById(R.id.naslovVesti);
                            naslovVesti.setText(v.getNaslov());

                            if(kategorijaTmp.equals("sport")) {
                                naslovVesti.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
                            }
                            else if(kategorijaTmp.equals("srbija")) {
                                naslovVesti.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                            }
                            else if(kategorijaTmp.equals("svet")) {
                                naslovVesti.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                            }
                            else
                                naslovVesti.setTextColor(getResources().getColor(android.R.color.holo_purple));

                            ImageView slikaVesti = (ImageView)vest.findViewById(R.id.slikaVesti);

                            if(v.getKategorija().equals("svet")) {
                                slikaVesti.setImageResource(R.drawable.svet_projekat_rma);
                            }
                            else if(v.getKategorija().equals("srbija")) {
                                slikaVesti.setImageResource(R.drawable.srbija_projekat_rma);
                            }
                            else if(v.getKategorija().equals("sport")) {
                                slikaVesti.setImageResource(R.drawable.sport_projekat_rma);
                            }
                            else {
                                slikaVesti.setImageResource(R.drawable.vesti_projekat_rma);
                            }

                            final String idToBePassed = v.getId();

                            vest.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent i = new Intent(MainActivity.this, PojedinacnaVestActivity.class);
                                    i.putExtra("id", idToBePassed);
                                    i.putExtra("jezik", jezik);
                                    startActivity(i);
                                }
                            });




                            mainElement.addView(vest);

                        }
                    }



                } catch (Exception e) {

                }
            }
        });
    }

    public void saveOnFile() {
        String kat = kategorija;
        String jez = jezik;
        try {
            FileOutputStream fileOutputStream = openFileOutput(APP_DATA_PREFIX, Context.MODE_PRIVATE);
            PrintWriter printWriter = new PrintWriter(fileOutputStream);

            printWriter.println(kat);
            printWriter.println(jez);
            printWriter.flush();
            printWriter.close();

            fileOutputStream.close();


        }
        catch (Exception e) {

        }
    }

    public void loadFromFile() {

        try {
            FileInputStream fileInputStream = openFileInput(APP_DATA_PREFIX);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));

            String kat = reader.readLine();
            String jez = reader.readLine();
            kategorija = kat;
            jezik = jez;

            ArrayAdapter<String> spinnerAdap = (ArrayAdapter<String>) jezikSpinner.getAdapter();
            jezikSpinner.setAdapter(spinnerAdap);
            int spinnerPosition = spinnerAdap.getPosition(jezik);
            jezikSpinner.setSelection(spinnerPosition);

        }
        catch (Exception e) {

        }

    }

    public void translate() {
        if(jezik.equals("Srpski")) {
            vestiButton.setText("Vesti");
            sportButton.setText("Sport");
            svetButton.setText("Svet");
            srbijaButton.setText("Srbija");
        }
        else {
            vestiButton.setText("News");
            sportButton.setText("Sport");
            svetButton.setText("World");
            srbijaButton.setText("Serbia");
        }
    }

    public String urlCheck() {
        if(jezik.equals("Srpski")) {
            return URL_SRB;
        }
        return URL_ENG;
    }
}
