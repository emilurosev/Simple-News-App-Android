package com.example.projekat;

import android.annotation.SuppressLint;
import android.media.Image;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

public class PojedinacnaVestActivity extends AppCompatActivity {
    TextView naslovPojedinacneVesti, datumPojedinacneVesti, sadrzajPojedinacneVesti;
    ImageView slikaPojedinacneVesti;
    ImageView goBack;

    private static final String URL_ENG = "http://192.168.0.16:5000/jsonEng/";
    private static final String URL_SRB = "http://192.168.0.16:5000/json/";
    private static String jezikPojedinacneVesti;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pojedinacna_vest);

        goBack = (ImageView) findViewById(R.id.backButton);
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        jezikPojedinacneVesti = getIntent().getStringExtra("jezik");
        String ID = getIntent().getStringExtra("id");
        initPojedinacnaVest(ID, urlCheck());


    }

    public String urlCheck() {
        if(jezikPojedinacneVesti.equals("Srpski")) {
            return URL_SRB;
        }
        return URL_ENG;
    }


    @SuppressLint("HandlerLeak")
    public void initPojedinacnaVest(String id, String url) {
        Api.dobaviVest(url+id, new ReadDataHandler() {
            @Override
            public void handleMessage(Message msg) {
                String odgovor = getResponseJsonString();
                try {
                    JSONObject jsonObject = new JSONObject(odgovor);
                    Vest vest = Vest.oneJSONObjectParsed(jsonObject);
                    slikaPojedinacneVesti = (ImageView)findViewById(R.id.slikaPojedinacneVest);
                    if(vest.getKategorija().equals("sport"))
                        slikaPojedinacneVesti.setImageResource(R.drawable.sport_projekat_rma);
                    else if(vest.getKategorija().equals("svet"))
                        slikaPojedinacneVesti.setBackgroundResource(R.drawable.svet_projekat_rma);
                    else if(vest.getKategorija().equals("srbija"))
                        slikaPojedinacneVesti.setBackgroundResource(R.drawable.srbija_projekat_rma);
                    else
                        slikaPojedinacneVesti.setBackgroundResource(R.drawable.vesti_projekat_rma);
                    naslovPojedinacneVesti = (TextView)findViewById(R.id.naslovPojedinacneVesti);
                    naslovPojedinacneVesti.setText(vest.getNaslov());
                    datumPojedinacneVesti = (TextView)findViewById(R.id.datumPojedinacneVesti);
                    datumPojedinacneVesti.setText(vest.getDatum());
                    sadrzajPojedinacneVesti = (TextView)findViewById(R.id.sadrzajPojedinacneVesti);
                    sadrzajPojedinacneVesti.setText(vest.getSadrzaj());


                } catch (Exception e) {
                    naslovPojedinacneVesti = (TextView)findViewById(R.id.naslovPojedinacneVesti);
                    naslovPojedinacneVesti.setText(odgovor);

                }

            }
        });
    }
}
